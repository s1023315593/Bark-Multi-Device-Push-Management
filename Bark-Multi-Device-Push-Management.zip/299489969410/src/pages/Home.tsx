import BarkSystem from './BarkSystem';

export default function Home() {
  return <BarkSystem />;
}